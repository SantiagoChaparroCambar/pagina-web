// Smooth scrolling para los links de navegación
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start'
            });
        }
    });
});

// Efecto de scroll en el header
window.addEventListener('scroll', () => {
    const header = document.querySelector('.header');
    if (window.scrollY > 50) {
        header.style.boxShadow = '0 8px 30px rgba(0, 212, 255, 0.3)';
    } else {
        header.style.boxShadow = '0 4px 20px rgba(0, 212, 255, 0.2)';
    }
});

// Intersection Observer para animaciones al scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.animation = 'slideUp 0.6s ease-out forwards';
        }
    });
}, observerOptions);

// Observar todas las tarjetas de servicios y productos
document.querySelectorAll('.servicio-card, .producto, .caracteristica').forEach(el => {
    el.style.opacity = '0';
    observer.observe(el);
});

// Manejo del formulario de contacto
const form = document.querySelector('.contacto-form');
if (form) {
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Obtener valores del formulario
        const nombre = form.querySelector('input[type="text"]').value;
        const email = form.querySelector('input[type="email"]').value;
        const telefono = form.querySelector('input[type="tel"]').value;
        const mensaje = form.querySelector('textarea').value;
        
        // Validación simple
        if (nombre && email && telefono && mensaje) {
            // Aquí se enviaría la información a un servidor
            alert(`¡Gracias ${nombre}! Tu mensaje ha sido recibido. Nos contactaremos pronto en ${email}`);
            form.reset();
        } else {
            alert('Por favor, completa todos los campos');
        }
    });
}

// Efecto hover en botones CTA
const ctaButtons = document.querySelectorAll('.cta-button');
ctaButtons.forEach(button => {
    button.addEventListener('mouseenter', function() {
        this.style.transform = 'translateY(-3px)';
    });
    
    button.addEventListener('mouseleave', function() {
        this.style.transform = 'translateY(0)';
    });
});

// Agregar evento a botones "Más Info"
const btnInfo = document.querySelectorAll('.btn-info');
btnInfo.forEach(button => {
    button.addEventListener('click', function() {
        const producto = this.closest('.producto');
        const nombre = producto.querySelector('h3').textContent;
        alert(`Para más información sobre "${nombre}", por favor contáctanos a info@powergen.com o llama al +1 (555) 123-4567`);
    });
});

// Animación de números ascendentes (si hay secciones con estadísticas)
function animateCounter(element, target, duration = 2000) {
    const start = 0;
    const increment = target / (duration / 16);
    let current = start;
    
    const counter = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target;
            clearInterval(counter);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 16);
}

// Parallax effect en la sección hero
window.addEventListener('scroll', () => {
    const hero = document.querySelector('.hero');
    if (hero) {
        const scrollY = window.scrollY;
        hero.style.backgroundPosition = `0 ${scrollY * 0.5}px`;
    }
});

// Crear efecto de partículas en el hero
function createParticles() {
    const hero = document.querySelector('.hero');
    if (!hero) return;
    
    // Crear contenedor para partículas
    const particleContainer = document.createElement('div');
    particleContainer.style.position = 'absolute';
    particleContainer.style.top = '0';
    particleContainer.style.left = '0';
    particleContainer.style.width = '100%';
    particleContainer.style.height = '100%';
    particleContainer.style.pointerEvents = 'none';
    particleContainer.style.zIndex = '1';
    
    for (let i = 0; i < 20; i++) {
        const particle = document.createElement('div');
        particle.style.position = 'absolute';
        particle.style.width = '4px';
        particle.style.height = '4px';
        particle.style.background = 'rgba(0, 212, 255, 0.5)';
        particle.style.borderRadius = '50%';
        particle.style.left = Math.random() * 100 + '%';
        particle.style.top = Math.random() * 100 + '%';
        particle.style.animation = `float ${3 + Math.random() * 4}s infinite ease-in-out`;
        particleContainer.appendChild(particle);
    }
    
    hero.appendChild(particleContainer);
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    createParticles();
});

// Efecto de carga de página
window.addEventListener('load', () => {
    document.body.style.opacity = '1';
});

document.body.style.opacity = '0';
document.body.style.transition = 'opacity 0.5s ease-in';
